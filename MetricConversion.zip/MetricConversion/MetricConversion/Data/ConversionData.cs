﻿using Dapper;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MetricConversion
{
    public class ConversionData : IConversionData
    {
        private readonly DapperContext _context;

        public  ConversionData(DapperContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<PhysicalSystem>> ListPhysicalSystem()
        {
            var query = "exec [dbo].[usp_ListPhysicalSystems]";
            using var connection = _context.CreateConnection();
            var PhysicalSystem = await connection.QueryAsync<PhysicalSystem>(query);
            return PhysicalSystem.ToList();
        }

        public async Task<IEnumerable<Unit>> ListUnits(string PhysicalSystemName)
        {
            var query = "exec [dbo].[usp_UnitsBasedOnPhysicalSystems] '" + PhysicalSystemName + "'";
            using var connection = _context.CreateConnection();
            var Units = await connection.QueryAsync<Unit>(query);
            return Units;
        }

        public async Task<Boolean> IsConversionCompatible(UnitConversionRequest unitConversionRequest)
        {
            var query = "exec [dbo].[usp_IsConversionCompatible] '" + unitConversionRequest.InitialUnit + "', '" + unitConversionRequest.TargetUnit + "'";
            using var connection = _context.CreateConnection();
            return await connection.QueryFirstAsync<Boolean>(query);
        }

        public async Task<Double> GetConversionValue(UnitConversionRequest unitConversionRequest)
        {
            var query = "exec [dbo].[usp_GetUnitConversionValue] '" + unitConversionRequest.InitialUnit + "', " + unitConversionRequest.InitialValue + ", '" + unitConversionRequest.TargetUnit+ "'";
            using var connection = _context.CreateConnection();
            return await connection.QueryFirstAsync<Double>(query);
        }


    }
}
