﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MetricConversion
{
    public interface IConversionData
    {
        public Task<IEnumerable<PhysicalSystem>> ListPhysicalSystem();

        public Task<IEnumerable<Unit>> ListUnits(string PhysicalSystemName);

        public Task<Boolean> IsConversionCompatible(UnitConversionRequest unitConversionRequest);

        public Task<Double> GetConversionValue(UnitConversionRequest unitConversionRequest);

    }
}
