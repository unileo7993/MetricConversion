﻿namespace MetricConversion
{
    public class Unit
    {
        public string UnitName { get; set; }
        public string ConversionType { get; set; }
    }
}
