﻿namespace MetricConversion
{
    public class PhysicalSystem
    {
        public string PhysicalSystemName { get; set; }
    }
}
