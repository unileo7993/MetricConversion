﻿namespace MetricConversion
{
    public class UnitConversionRequest
    {
        public string InitialUnit { get; set; }

        public double InitialValue { get; set; }

        public string TargetUnit { get; set; }
    }
}
