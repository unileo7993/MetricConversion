﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace MetricConversion.Controllers
{
    [ApiController]
    public class ConversionController : ControllerBase
    {


        private readonly ILogger<ConversionController> _logger;
        private readonly IConversionData _conversionData;

        public ConversionController(ILogger<ConversionController> logger, IConversionData conversionData)
        {
            _logger = logger;
            _conversionData = conversionData;
        }

        [HttpGet]
        [Route("physical-system-list")]
        public IActionResult ListPhysicalSystems()
        {
            var Result = _conversionData.ListPhysicalSystem().Result;
            return Ok(Result);
        }

        [HttpGet]
        [Route("unit-list")]
        public IActionResult ListUnits([FromQuery] string PhysicalSystem)
        {
            var Result = _conversionData.ListUnits(PhysicalSystem).Result;
            return Ok(Result);
        }

        [HttpPost]
        [Route("conversion-value")]
        public  IActionResult ConversionValue(UnitConversionRequest unitConversionRequest)
        {
            if (!_conversionData.IsConversionCompatible(unitConversionRequest).Result)
            {
                return BadRequest("Conversion not compatible between " + unitConversionRequest.InitialUnit + " and " + unitConversionRequest.TargetUnit);
            }
            var Result = _conversionData.GetConversionValue(unitConversionRequest).Result;
            if(Result == 0)
            {
                return BadRequest("Conversion not found between " + unitConversionRequest.InitialUnit + " and " + unitConversionRequest.TargetUnit);
            }
            return Ok(Result);
        }

    }
}
